


In this project I implemeted BloC pattern for the todo list and theme picker like this:

<img src="media/bloc-diagram.png">

## Libraries used

| library | version | 
| ------- | ------- | 
| [flutter_bloc](https://pub.dev/packages/flutter_bloc) | 8.1.3 | 
| [equatable](https://pub.dev/packages/equatable)     | 2.0.5 |
| [hive](https://pub.dev/packages/hive) | 2.2.3 |
| [hive_flutter](https://pub.dev/packages/hive_flutter) | 1.1.0 |
| [build_runner](https://pub.dev/packages/build_runner) | 2.4.6 |



